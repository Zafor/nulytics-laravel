
<?php $__env->startSection('content'); ?>

     <!-- Call To Action Area -->
     <section class="callto-action-area bg-theme">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                            <div class="callto-action">
                                <div class="callto-action-inner">
                                    <h2>To start your project with us</h2>
                                    <a href="contact" class="cr-btn cr-btn-white">
                                        <span>Contact Us</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--// Call To Action Area -->

<?php $__env->stopSection(); ?><?php /**PATH C:\Users\Zafor Iqbal\Desktop\nulytics-laravel\nulytics-website\resources\views/partials/calltoaction.blade.php ENDPATH**/ ?>